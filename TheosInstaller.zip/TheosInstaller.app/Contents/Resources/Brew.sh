#!/bin/sh

#  Brew.sh
#  TheosInstaller
#
#  Created by iMac on 06/12/2019.
#  Copyright © 2019 yuosaf01. All rights reserved.

LOCAL=/usr/local
VAR=$LOCAL/var
Cellar=$LOCAL/Cellar
Password=$1
if [ ! -d "$VAR" ]; then
  echo "$Password" | sudo -S mkdir $VAR
  echo "$Password" | sudo -S chown -R $(whoami) $VAR
  echo "$Password" | sudo -S chmod u+w $VAR
fi
if [ ! -d "$Cellar" ]; then
  echo "$Password" | sudo -S mkdir $Cellar
  echo "$Password" | sudo -S chown -R $(whoami) $Cellar
  echo "$Password" | sudo -S chmod u+w $Cellar
fi
if [ ! -d "$VAR/Homebrew" ]; then
  cd $VAR
  git clone --recursive https://github.com/Homebrew/brew
  mv brew Homebrew
fi

/bin/ln -s $VAR/Homebrew/bin/brew $LOCAL/bin/brew
$VAR/Homebrew/bin/brew install ldid xz dpkg wget unzip https://raw.githubusercontent.com/kadwanev/bigboybrew/master/Library/Formula/sshpass.rb
