#!/bin/sh

#  Theos.sh
#  TheosInstaller
#
#  Created by iMac on 06/12/2019.
#  Copyright © 2019 yuosaf01. All rights reserved.

PATH=~/theos
Password=$1

if [ ! -d $PATH ]; then

  echo "export THEOS='$PATH'" >> ~/.profile
  cd ~/
  /usr/bin/git clone --recursive https://github.com/theos/theos.git

fi
